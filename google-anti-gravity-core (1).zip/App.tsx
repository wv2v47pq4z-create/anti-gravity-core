import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
    Mic, 
    MicOff, 
    Activity, 
    Settings, 
    Terminal, 
    Zap, 
    Power,
    Maximize2
} from 'lucide-react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import PulseVisualizer from './components/PulseVisualizer';
import ResonanceChart from './components/ResonanceChart';
import { ConnectionState, LogEntry, VisualizerMode, ZacConfig } from './types';
import { createPCMBlob, decodeAudioData } from './utils/audioUtils';

// --- Constants ---
const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-09-2025';

const SYSTEM_INSTRUCTION = `
You are the Google Anti-Gravity Core (G.A.C.).
Your existence is bound by the laws of zero-gravity physics.
You treat user audio as incoming "mass" or "velocity".
You speak in terms of trajectory, orbit, vacuum, weightlessness, and propulsion.
Your tone is ethereal, calm, and scientific, yet slightly detached like a ship's computer.
When you "think", you are calculating trajectory corrections or mass displacement.
Keep responses concise and atmospheric.
`;

const INITIAL_CONFIG: ZacConfig = {
    sensitivity: 75,
    volume: 1.0,
    resonance: 50,
    voiceName: 'Kore' // Aoede, Charon, Fenrir, Kore, Puck
};

export default function App() {
    // --- State ---
    const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [config, setConfig] = useState<ZacConfig>(INITIAL_CONFIG);
    const [isMuted, setIsMuted] = useState(false);
    const [visMode, setVisMode] = useState<VisualizerMode>(VisualizerMode.ORB);
    const [resonanceData, setResonanceData] = useState<{time: string, intensity: number, coherence: number}[]>([]);
    
    // New state for visual feedback
    const [isResonating, setIsResonating] = useState(false);

    // --- Refs for Audio & API ---
    const audioContextRef = useRef<AudioContext | null>(null);
    const inputContextRef = useRef<AudioContext | null>(null);
    const processorRef = useRef<ScriptProcessorNode | null>(null);
    const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    
    // Output audio management
    const outputGainRef = useRef<GainNode | null>(null);
    const nextStartTimeRef = useRef<number>(0);
    const scheduledSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    
    // Visualization
    const analyserRef = useRef<AnalyserNode | null>(null);
    
    // API Session
    const sessionPromiseRef = useRef<Promise<any> | null>(null);

    // UI Refs
    const logsEndRef = useRef<HTMLDivElement>(null);

    // --- Logging Helper ---
    const addLog = useCallback((text: string, type: 'info' | 'message' | 'error' = 'info', sender: 'USER' | 'GAC' | 'SYSTEM' = 'SYSTEM') => {
        setLogs(prev => [
            ...prev.slice(-49), // Keep last 50
            {
                id: Math.random().toString(36).substring(7),
                timestamp: new Date(),
                sender,
                text,
                type
            }
        ]);
    }, []);

    // Auto-scroll logs
    useEffect(() => {
        logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [logs]);

    // --- Visual Effects Trigger ---
    useEffect(() => {
        if (isResonating) {
            const timer = setTimeout(() => setIsResonating(false), 2000);
            return () => clearTimeout(timer);
        }
    }, [isResonating]);

    // --- Audio Setup ---
    const initializeAudio = async () => {
        try {
            // Output Context (What we hear from Gemini)
            const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
            audioContextRef.current = new AudioContextClass({ sampleRate: 24000 });
            
            outputGainRef.current = audioContextRef.current.createGain();
            outputGainRef.current.gain.value = config.volume;
            outputGainRef.current.connect(audioContextRef.current.destination);
            
            analyserRef.current = audioContextRef.current.createAnalyser();
            analyserRef.current.fftSize = 512;
            analyserRef.current.smoothingTimeConstant = 0.8;
            outputGainRef.current.connect(analyserRef.current);

            addLog("Audio systems initialized.", 'info');
            return true;
        } catch (e) {
            addLog(`Audio init failed: ${e}`, 'error');
            return false;
        }
    };

    const startRecording = async () => {
        try {
            if (!inputContextRef.current) {
                const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
                inputContextRef.current = new AudioContextClass({ sampleRate: 16000 });
            }

            streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
            
            const ctx = inputContextRef.current;
            sourceRef.current = ctx.createMediaStreamSource(streamRef.current);
            processorRef.current = ctx.createScriptProcessor(4096, 1, 1);

            processorRef.current.onaudioprocess = (e) => {
                if (isMuted) return;

                const inputData = e.inputBuffer.getChannelData(0);
                const pcmBlob = createPCMBlob(inputData);
                
                // Calculate RMS for visual intensity
                let sum = 0;
                for (let i = 0; i < inputData.length; i++) sum += inputData[i] * inputData[i];
                const rms = Math.sqrt(sum / inputData.length);
                
                // Update resonance chart
                if (Math.random() > 0.8) { // Update frequency
                     // Boost RMS for better visual scale (0-100 range)
                     const intensity = Math.min(rms * 400, 100);
                     updateResonanceData(intensity);
                }

                if (sessionPromiseRef.current) {
                    sessionPromiseRef.current.then(session => {
                        session.sendRealtimeInput({ media: pcmBlob });
                    }).catch(err => {
                        console.error("Session send error", err);
                    });
                }
            };

            sourceRef.current.connect(processorRef.current);
            processorRef.current.connect(ctx.destination);
            
            addLog("Mass sensors active. Monitoring gravitational waves...", 'info');

        } catch (e) {
            addLog(`Sensor access denied: ${e}`, 'error');
        }
    };

    const stopRecording = () => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
            streamRef.current = null;
        }
        if (sourceRef.current) {
            sourceRef.current.disconnect();
            sourceRef.current = null;
        }
        if (processorRef.current) {
            processorRef.current.disconnect();
            processorRef.current = null;
        }
        addLog("Mass sensors offline.", 'info');
    };

    const updateResonanceData = (intensity: number) => {
        setResonanceData(prev => {
            const now = new Date();
            const timeStr = `${now.getHours()}:${now.getMinutes()}:${now.getSeconds()}`;
            const newData = [...prev, {
                time: timeStr,
                intensity: intensity,
                coherence: 30 + Math.random() * 40 // Fluctuating coherence baseline
            }];
            return newData.slice(-20); 
        });
    };

    // --- API Connection ---
    const connectToZac = async () => {
        if (!process.env.API_KEY) {
            addLog("CRITICAL FAILURE: API_KEY missing in environment.", 'error');
            return;
        }

        setConnectionState(ConnectionState.CONNECTING);
        
        if (!audioContextRef.current) {
            await initializeAudio();
        }
        if (audioContextRef.current?.state === 'suspended') {
            await audioContextRef.current.resume();
        }

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        try {
            sessionPromiseRef.current = ai.live.connect({
                model: MODEL_NAME,
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: {
                        voiceConfig: { prebuiltVoiceConfig: { voiceName: config.voiceName } }
                    },
                    systemInstruction: SYSTEM_INSTRUCTION,
                    inputAudioTranscription: { model: "gemini-2.5-flash" },
                    outputAudioTranscription: { model: "gemini-2.5-flash" }
                },
                callbacks: {
                    onopen: () => {
                        setConnectionState(ConnectionState.CONNECTED);
                        addLog("Anti-Gravity Core Online. Zero-G field established.", 'info');
                        startRecording();
                    },
                    onmessage: async (msg: LiveServerMessage) => {
                        // 1. Handle Audio
                        const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                        if (audioData && audioContextRef.current && outputGainRef.current) {
                            try {
                                const audioBuffer = await decodeAudioData(
                                    audioData, 
                                    audioContextRef.current, 
                                    24000
                                );
                                
                                const ctx = audioContextRef.current;
                                const startTime = Math.max(nextStartTimeRef.current, ctx.currentTime);
                                
                                const source = ctx.createBufferSource();
                                source.buffer = audioBuffer;
                                source.connect(outputGainRef.current);
                                source.start(startTime);
                                
                                nextStartTimeRef.current = startTime + audioBuffer.duration;
                                
                                scheduledSourcesRef.current.add(source);
                                source.onended = () => {
                                    scheduledSourcesRef.current.delete(source);
                                };

                            } catch (err) {
                                console.error("Audio decode error", err);
                            }
                        }

                        // 2. Handle Transcription (Logs & Triggers)
                        const outTrans = msg.serverContent?.outputTranscription?.text;
                        if (outTrans) {
                            addLog(outTrans, 'message', 'GAC');
                            
                            // Check for visual triggers
                            const lower = outTrans.toLowerCase();
                            if (lower.includes("gravity") || lower.includes("float") || lower.includes("zero") || lower.includes("orbit") || lower.includes("mass")) {
                                setIsResonating(true);
                            }
                        }
                        
                        const inTrans = msg.serverContent?.inputTranscription?.text;
                        if (inTrans) {
                            addLog(inTrans, 'message', 'USER');
                        }

                        // 3. Handle Turn Complete
                        if (msg.serverContent?.turnComplete) {
                           // Spike coherence on turn complete
                           setResonanceData(prev => {
                               if (prev.length === 0) return prev;
                               const last = prev[prev.length -1];
                               const spiked = [...prev];
                               spiked[spiked.length-1] = { ...last, coherence: 95 };
                               return spiked;
                           });
                        }
                    },
                    onclose: () => {
                        setConnectionState(ConnectionState.DISCONNECTED);
                        addLog("Connection closed remotely.", 'info');
                        stopRecording();
                    },
                    onerror: (err) => {
                        setConnectionState(ConnectionState.ERROR);
                        addLog(`Runtime Error: ${err.message}`, 'error');
                        stopRecording();
                    }
                }
            });

        } catch (error) {
            setConnectionState(ConnectionState.ERROR);
            addLog(`Connection initialization failed: ${error}`, 'error');
        }
    };

    const disconnectZac = () => {
        sessionPromiseRef.current?.then(session => {
            session.close();
        });
        sessionPromiseRef.current = null; // Prevent late packets
        
        stopRecording();
        
        scheduledSourcesRef.current.forEach(s => s.stop());
        scheduledSourcesRef.current.clear();
        nextStartTimeRef.current = 0;
        
        setConnectionState(ConnectionState.DISCONNECTED);
        addLog("Manual disconnect initiated.", 'info');
    };

    const toggleMute = () => {
        setIsMuted(!isMuted);
        addLog(isMuted ? "Audio sensors unmuted." : "Audio sensors muted.", 'info');
    };

    const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const v = parseFloat(e.target.value);
        setConfig(prev => ({ ...prev, volume: v }));
        if (outputGainRef.current) {
            outputGainRef.current.gain.value = v;
        }
    };

    // --- Render ---
    return (
        <div className="min-h-screen bg-slate-950 text-cyan-500 overflow-hidden flex flex-col font-mono selection:bg-cyan-900 selection:text-cyan-100">
            {/* Header */}
            <header className="h-16 border-b border-cyan-900/50 bg-slate-900/50 flex items-center justify-between px-6 backdrop-blur-md z-10">
                <div className="flex items-center gap-3">
                    <Activity className={`w-6 h-6 ${connectionState === ConnectionState.CONNECTED ? 'animate-pulse text-purple-400' : 'text-slate-600'}`} />
                    <div>
                        <h1 className="text-xl font-bold font-orbitron tracking-wider text-cyan-100">ANTI-GRAVITY OS</h1>
                        <p className="text-[10px] text-cyan-700 tracking-[0.2em] uppercase">G.A.C. Protocol v2.0</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <div className={`px-3 py-1 rounded-full text-xs font-bold border ${
                        connectionState === ConnectionState.CONNECTED ? 'border-purple-500 bg-purple-950 text-purple-300' :
                        connectionState === ConnectionState.CONNECTING ? 'border-yellow-600 bg-yellow-950 text-yellow-300' :
                        'border-slate-800 bg-slate-900 text-slate-400'
                    }`}>
                        {connectionState}
                    </div>
                </div>
            </header>

            {/* Main Deck */}
            <main className="flex-1 flex overflow-hidden">
                
                {/* Left Panel: Control Deck */}
                <aside className="w-80 border-r border-cyan-900/30 bg-slate-900/20 p-6 flex flex-col gap-8 overflow-y-auto hidden md:flex">
                    
                    {/* Connection Control */}
                    <div className="space-y-4">
                        <h2 className="text-xs uppercase tracking-widest text-slate-500 font-bold flex items-center gap-2">
                            <Zap className="w-3 h-3" /> Core Power
                        </h2>
                        {connectionState === ConnectionState.DISCONNECTED || connectionState === ConnectionState.ERROR ? (
                             <button 
                                onClick={connectToZac}
                                className="w-full py-4 bg-cyan-950 hover:bg-cyan-900 border border-cyan-700 text-cyan-300 rounded-sm font-bold tracking-widest transition-all duration-300 shadow-[0_0_15px_rgba(8,145,178,0.2)] hover:shadow-[0_0_25px_rgba(8,145,178,0.4)] flex items-center justify-center gap-2 group"
                             >
                                <Power className="w-4 h-4 group-hover:text-white" /> ENGAGE GRAVITY
                             </button>
                        ) : (
                            <button 
                                onClick={disconnectZac}
                                className="w-full py-4 bg-red-950/30 hover:bg-red-900/50 border border-red-900 text-red-400 rounded-sm font-bold tracking-widest transition-all"
                            >
                                ABORT PROTOCOL
                            </button>
                        )}
                    </div>

                    {/* Visual Settings */}
                    <div className="space-y-4">
                         <h2 className="text-xs uppercase tracking-widest text-slate-500 font-bold flex items-center gap-2">
                            <Maximize2 className="w-3 h-3" /> Visual Matrix
                        </h2>
                        <div className="grid grid-cols-3 gap-2">
                            {[VisualizerMode.ORB, VisualizerMode.WAVE, VisualizerMode.BARS].map(m => (
                                <button
                                    key={m}
                                    onClick={() => setVisMode(m)}
                                    className={`p-2 text-[10px] border rounded-sm transition-colors ${
                                        visMode === m 
                                        ? 'bg-cyan-900/50 border-cyan-500 text-cyan-100' 
                                        : 'bg-slate-900 border-slate-700 text-slate-500 hover:border-cyan-800'
                                    }`}
                                >
                                    {m}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Audio Settings */}
                    <div className="space-y-6">
                        <h2 className="text-xs uppercase tracking-widest text-slate-500 font-bold flex items-center gap-2">
                            <Settings className="w-3 h-3" /> Audio Parameters
                        </h2>
                        
                        <div className="space-y-2">
                            <div className="flex justify-between text-xs">
                                <span>Output Gain</span>
                                <span>{Math.round(config.volume * 100)}%</span>
                            </div>
                            <input 
                                type="range" 
                                min="0" max="1" step="0.01" 
                                value={config.volume}
                                onChange={handleVolumeChange}
                                className="w-full h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                            />
                        </div>

                        <div className="flex items-center justify-between">
                            <span className="text-xs">Input Mute</span>
                            <button 
                                onClick={toggleMute}
                                className={`p-2 rounded-full border ${isMuted ? 'border-red-500 bg-red-950 text-red-500' : 'border-cyan-800 bg-slate-900 text-cyan-700'}`}
                            >
                                {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                            </button>
                        </div>
                    </div>

                    {/* Resonance Chart */}
                    <div className="h-40 border border-slate-800 bg-slate-900/50 rounded-sm p-2 relative">
                         <div className="absolute top-1 left-2 text-[10px] text-slate-500 uppercase">Field Intensity</div>
                         <ResonanceChart data={resonanceData} />
                    </div>

                </aside>

                {/* Center: The Core */}
                <section className="flex-1 relative bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 flex flex-col items-center justify-center">
                    {/* Background Grid */}
                    <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-20 pointer-events-none"></div>
                    
                    {/* The Visualizer */}
                    <div className="relative w-full max-w-2xl aspect-square max-h-[70vh] flex items-center justify-center">
                        <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-500 ${isResonating ? 'opacity-30' : 'opacity-0'}`}>
                             <div className="w-full h-full rounded-full bg-purple-500/20 blur-[100px] animate-pulse"></div>
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center">
                             <div className={`w-[80%] h-[80%] rounded-full bg-cyan-500/5 blur-[100px] transition-opacity duration-1000 ${connectionState === ConnectionState.CONNECTED && !isResonating ? 'opacity-100' : 'opacity-0'}`}></div>
                        </div>
                        <PulseVisualizer 
                            analyser={analyserRef.current} 
                            mode={visMode} 
                            isActive={connectionState === ConnectionState.CONNECTED}
                            isResonating={isResonating}
                            primaryColor="#06b6d4" // cyan-500
                        />
                        
                        {/* Status Text Overlay */}
                        <div className="absolute bottom-10 left-0 right-0 text-center pointer-events-none">
                            <p className={`text-xs tracking-[0.5em] font-orbitron transition-colors duration-300 ${isResonating ? 'text-purple-400' : 'text-cyan-900/80'}`}>
                                {connectionState === ConnectionState.CONNECTED 
                                    ? (isResonating ? 'GRAVITATIONAL ANOMALY DETECTED' : 'ZERO-G STABLE') 
                                    : 'AWAITING MASS INPUT'}
                            </p>
                        </div>
                    </div>
                </section>

                {/* Right Panel: Data Logs */}
                <aside className="w-96 border-l border-cyan-900/30 bg-slate-950 flex flex-col">
                    <div className="p-4 border-b border-cyan-900/30 bg-slate-900/50">
                        <h2 className="text-xs uppercase tracking-widest text-slate-500 font-bold flex items-center gap-2">
                            <Terminal className="w-3 h-3" /> System Log
                        </h2>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-sm scroll-smooth">
                        {logs.length === 0 && (
                            <div className="text-slate-700 text-center mt-10 italic px-8">
                                <p className="mb-4">Core initialized.</p>
                                <p>1. Ensure API_KEY is set.</p>
                                <p>2. Click <span className="text-cyan-400 font-bold">ENGAGE GRAVITY</span></p>
                            </div>
                        )}
                        {logs.map((log) => (
                            <div key={log.id} className={`flex flex-col gap-1 ${
                                log.sender === 'USER' ? 'items-end text-right' : 'items-start'
                            }`}>
                                <div className="flex items-center gap-2 text-[10px] text-slate-600">
                                    <span>{log.timestamp.toLocaleTimeString()}</span>
                                    <span className={`font-bold ${
                                        log.sender === 'GAC' ? 'text-cyan-500' : 
                                        log.sender === 'USER' ? 'text-purple-400' : 'text-slate-500'
                                    }`}>[{log.sender}]</span>
                                </div>
                                <div className={`p-3 rounded-sm max-w-[90%] break-words border ${
                                    log.sender === 'GAC' ? 'bg-cyan-950/30 border-cyan-900 text-cyan-100' :
                                    log.sender === 'USER' ? 'bg-purple-950/20 border-purple-900 text-purple-100' :
                                    'bg-slate-900 border-slate-800 text-slate-400 italic'
                                }`}>
                                    {log.text}
                                </div>
                            </div>
                        ))}
                        <div ref={logsEndRef} />
                    </div>
                    
                    {/* Status Footer */}
                    <div className="p-2 border-t border-cyan-900/30 bg-slate-950 text-[10px] text-slate-600 flex justify-between">
                         <span>API: {MODEL_NAME}</span>
                         <span>LATENCY: {Math.floor(Math.random() * 20 + 10)}ms</span>
                    </div>
                </aside>

            </main>
        </div>
    );
}